#!/usr/bin/env python3
import json, pathlib, sys
meta=json.loads(pathlib.Path(sys.argv[1]).read_text(encoding="utf-8"))
if not isinstance(meta,list) or len(meta)!=114: raise SystemExit(f"Expected metadata for 114 surahs, got {len(meta) if isinstance(meta,list) else 'invalid'}")
starts=[int(x["start_page"]) for x in meta]
if starts[0]!=1 or any(not 1<=x<=604 for x in starts) or starts!=sorted(starts): raise SystemExit("Invalid surah start-page metadata")
out=pathlib.Path(sys.argv[2]); out.parent.mkdir(parents=True,exist_ok=True)
out.write_text("package org.noorlayantafi.app\n\ninternal object SurahPages {\n    val startPages = listOf("+", ".join(map(str,starts))+ ")\n}\n",encoding="utf-8")
print("Generated validated page mapping for 114 surahs.")
