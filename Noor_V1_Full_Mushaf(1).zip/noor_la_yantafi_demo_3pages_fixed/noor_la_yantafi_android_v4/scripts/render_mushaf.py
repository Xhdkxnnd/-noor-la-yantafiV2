#!/usr/bin/env python3
"""Render and validate all 604 official King Fahd Complex Hafs pages."""
import re, subprocess, sys, tempfile
from pathlib import Path
if len(sys.argv) != 3:
    raise SystemExit("Usage: render_mushaf.py <unzipped-ai-directory> <output-assets-directory>")
source, output = Path(sys.argv[1]), Path(sys.argv[2])
pages=[]
for path in source.rglob("*.ai"):
    match=re.match(r"^(\d{3})___Hafs39__DM\.ai$", path.name, re.I)
    if match: pages.append((int(match.group(1)), path))
pages.sort(key=lambda item:item[0])
expected=list(range(1,605)); actual=[n for n,_ in pages]
if actual != expected:
    raise SystemExit(f"Expected exactly 604 numbered Hafs pages; found {len(actual)}; first/last={actual[:3]}/{actual[-3:]}")
output.mkdir(parents=True,exist_ok=True)
for old in output.glob("*.jpg"): old.unlink()
with tempfile.TemporaryDirectory(prefix="noor-mushaf-") as td:
    tmp=Path(td)
    for number, ai in pages:
        png=tmp/f"{number:03d}.png"; jpg=output/f"{number:03d}.jpg"
        subprocess.run(["inkscape",str(ai),"--export-area-page","--export-width=1800","--export-background=#f7f5ef","--export-background-opacity=1",f"--export-filename={png}"],check=True,stdout=subprocess.DEVNULL)
        subprocess.run(["convert",str(png),"-background","#f7f5ef","-alpha","remove","-alpha","off","-strip","-quality","93",str(jpg)],check=True,stdout=subprocess.DEVNULL)
        png.unlink(missing_ok=True)
        if number % 25 == 0: print(f"Rendered {number}/604",flush=True)
rendered=sorted(p.name for p in output.glob("*.jpg"))
expected_names=[f"{n:03d}.jpg" for n in range(1,605)]
if rendered != expected_names: raise SystemExit(f"Output validation failed: {len(rendered)} images")
print("Verified: exactly 604 official Hafs pages rendered.")
