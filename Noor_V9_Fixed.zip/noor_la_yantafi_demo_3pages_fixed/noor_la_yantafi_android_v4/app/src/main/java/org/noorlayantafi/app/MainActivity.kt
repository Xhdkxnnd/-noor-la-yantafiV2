package org.noorlayantafi.app

import android.content.Context
import android.os.Bundle
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Green = Color(0xFF173F36)
private val Gold = Color(0xFFC7A568)
private val Paper = Color(0xFFF7F4EC)
private val Surahs = listOf("الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس", "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه", "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم", "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر", "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق", "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة", "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج", "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس", "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد", "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات", "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر", "المسد", "الإخلاص", "الفلق", "الناس")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Edge-to-edge: ترسم الواجهة خلفية شريط الحالة داخل مساحة Insets نفسها.
        // جعل أشرطة النظام شفافة يمنع ظهور لون افتراضي متعارض مع خلفية Compose.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.rgb(18, 48, 42)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        setContent { NoorApp() }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable private fun NoorApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("noor_reader", Context.MODE_PRIVATE) }
    var page by rememberSaveable { mutableIntStateOf(prefs.getInt("last_page", 1).coerceIn(1, 3)) }
    var bookmark by rememberSaveable { mutableIntStateOf(prefs.getInt("bookmark_page", 1).coerceIn(1, 3)) }
    var screen by rememberSaveable { mutableStateOf("home") }
    var dark by rememberSaveable { mutableStateOf(prefs.getBoolean("dark", false)) }
    var query by rememberSaveable { mutableStateOf("") }
    var navigationMode by rememberSaveable { mutableStateOf(prefs.getString("navigation_mode", "both") ?: "both") }
    val pager = rememberPagerState(initialPage = page - 1, pageCount = { 3 })
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val stableStatusBarHeight = with(density) {
        WindowInsets.statusBarsIgnoringVisibility.getTop(this).toDp()
    }
    val stableNavigationBarHeight = with(density) {
        WindowInsets.navigationBarsIgnoringVisibility.getBottom(this).toDp()
    }
    LaunchedEffect(pager.currentPage) {
        page = pager.currentPage + 1
        prefs.edit().putInt("last_page", page).apply()
    }
    BackHandler(enabled = screen != "home") {
        screen = when (screen) { "reader" -> "index"; "settings" -> "home"; else -> "home" }
    }
    val bg = if (dark) Color(0xFF101B18) else Paper
    val surface = if (dark) Color(0xFF1D2A26) else Color.White
    val ink = if (dark) Color(0xFFECE8DE) else Green

    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Color(0xFFB7D3C5), secondary = Gold, background = bg, surface = surface) else lightColorScheme(primary = Green, secondary = Gold, background = bg, surface = surface)) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Box(Modifier.fillMaxSize()) {
                Scaffold(containerColor = bg) { pad ->
                    when (screen) {
                    "reader" -> ReaderScreen(
                        pager = pager, bookmark = bookmark, dark = dark, navigationMode = navigationMode,
                        stableStatusBarHeight = stableStatusBarHeight,
                        stableNavigationBarHeight = stableNavigationBarHeight,
                        onBack = { screen = "index" },
                        onBookmark = { bookmark = page; prefs.edit().putInt("bookmark_page", page).apply() }
                    )
                    "index" -> IndexScreen(
                        query = query,
                        onQueryChange = { query = it },
                        onOpenReader = { i ->
                            screen = "reader"
                            scope.launch { pager.animateScrollToPage(i.coerceAtMost(2)) }
                        },
                        surface = surface,
                        ink = ink
                    )
                    "settings" -> Column(Modifier.fillMaxSize().padding(pad).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("الإعدادات", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = ink)
                        Card(colors = CardDefaults.cardColors(containerColor = surface)) {
                            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) { Text("الوضع الليلي", color = ink, fontWeight = FontWeight.Bold); Text("تغيير مظهر التطبيق", color = ink.copy(alpha = .6f), fontSize = 12.sp) }
                                Switch(dark, { dark = it; prefs.edit().putBoolean("dark", it).apply() })
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = surface)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("طريقة تقليب الصفحات", color = ink, fontWeight = FontWeight.Bold)
                                listOf("buttons" to "الأزرار فقط", "swipe" to "السحب فقط", "both" to "السحب والأزرار معًا").forEach { (value, label) ->
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable {
                                        navigationMode = value; prefs.edit().putString("navigation_mode", value).apply()
                                    }) {
                                        RadioButton(selected = navigationMode == value, onClick = { navigationMode = value; prefs.edit().putString("navigation_mode", value).apply() })
                                        Text(label, color = ink)
                                    }
                                }
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = surface)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("العلامة المرجعية", color = ink, fontWeight = FontWeight.Bold)
                                Text("الصفحة $bookmark", color = ink)
                                TextButton(onClick = { screen = "reader"; scope.launch { pager.animateScrollToPage(bookmark - 1) } }) { Text("العودة إلى العلامة") }
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = surface)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("عن التطبيق", color = ink, fontWeight = FontWeight.Bold)
                                Text("نورٌ لا ينطفئ", color = ink, fontSize = 18.sp)
                                Text("القرآن الكريم · رواية حفص", color = ink.copy(alpha = .7f), fontSize = 12.sp)
                                Text("نسخة تجريبية · 3 صفحات", color = Gold, fontSize = 12.sp)
                            }
                        }
                    }
                    else -> HomeScreen(
                        page = page, dark = dark, onQuran = { screen = "index" },
                        onSettings = { screen = "settings" },
                        onBookmark = { screen = "reader"; scope.launch { pager.animateScrollToPage(bookmark - 1) } }
                    )
                    }
                }
                // خلفية مستقلة لشريط الحالة: أسود في الشاشات العامة وأخضر في القراءة.
                Box(
                    Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .height(stableStatusBarHeight)
                        .background(if (screen == "reader") Green else Color.Black)
                )
            }
        }
    }
}



@Composable private fun IndexScreen(
    query: String,
    onQueryChange: (String) -> Unit,
    onOpenReader: (Int) -> Unit,
    surface: Color,
    ink: Color
) {
    var searchExpanded by rememberSaveable { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("فهرس السور", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = ink,
                modifier = Modifier.weight(1f))
            IconButton(onClick = {
                searchExpanded = !searchExpanded
                if (!searchExpanded) onQueryChange("")
            }) {
                Icon(if (searchExpanded) Icons.Default.Close else Icons.Default.Search,
                    contentDescription = if (searchExpanded) "إغلاق البحث" else "بحث عن سورة", tint = ink)
            }
        }
        Text("النسخة التجريبية تعرض أول ثلاث صفحات فقط", color = Gold, fontSize = 13.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
        if (searchExpanded) {
            OutlinedTextField(value = query, onValueChange = onQueryChange,
                modifier = Modifier.fillMaxWidth(), placeholder = { Text("اكتب اسم السورة") },
                singleLine = true, shape = RoundedCornerShape(14.dp))
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 12.dp)) {
            val filtered = Surahs.indices.filter { query.isBlank() || Surahs[it].contains(query.trim()) }
            items(filtered.size) { position ->
                val i = filtered[position]
                val available = i < 2
                Card(Modifier.fillMaxWidth().clickable(enabled = available) { onOpenReader(i) },
                    colors = CardDefaults.cardColors(containerColor = surface)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.width(34.dp))
                        Column(Modifier.weight(1f)) {
                            Text(Surahs[i], color = ink, fontWeight = FontWeight.SemiBold,
                                fontSize = 19.sp, fontFamily = FontFamily.Serif)
                            Text(if (i == 0) "مكية · 7 آيات · صفحة 1"
                                else if (i == 1) "مدنية · تبدأ في الصفحة 2"
                                else "متاحة في النسخة الكاملة لاحقًا",
                                color = ink.copy(alpha = .65f), fontSize = 11.sp)
                        }
                        if (available) Icon(Icons.Default.MenuBook, null, tint = Gold)
                        else Text("لاحقًا", fontSize = 11.sp, color = ink.copy(alpha = .45f))
                    }
                }
            }
        }
    }
}

@Composable private fun HomeScreen(page: Int, dark: Boolean, onQuran: () -> Unit, onSettings: () -> Unit, onBookmark: () -> Unit) {
    val bg = if (dark) Color(0xFF101B18) else Paper
    val ink = if (dark) Color(0xFFECE8DE) else Green
    Column(
        Modifier.fillMaxSize().background(bg)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(28.dp)).background(Green), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("۞", fontSize = 36.sp, color = Gold)
                Text("نورٌ لا ينطفئ", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
        Row(Modifier.fillMaxWidth().height(220.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HomeImageOption("القرآن الكريم", "mushaf-home.jpg", Modifier.weight(1f), onQuran)
            HomeImageOption("الأذكار", "dua-home.jpg", Modifier.weight(1f), {})
        }
        Card(Modifier.fillMaxWidth().height(82.dp).clickable(onClick = onSettings), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = if (dark) Color(0xFF1D2A26) else Color.White), elevation = CardDefaults.cardElevation(3.dp)) {
            Row(Modifier.fillMaxSize().padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Icon(Icons.Default.Settings, null, tint = Gold, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(12.dp))
                Text("الإعدادات", color = ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.weight(1f))
        TextButton(onClick = onBookmark, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("متابعة القراءة · الصفحة $page", color = ink) }
    }
}

@Composable private fun HomeImageOption(title: String, assetName: String, modifier: Modifier, onClick: () -> Unit) {
    val context = LocalContext.current
    val bitmap by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, assetName) {
        value = withContext(Dispatchers.IO) {
            runCatching { context.assets.open(assetName).use { BitmapFactory.decodeStream(it)?.asImageBitmap() } }.getOrNull()
        }
    }
    Card(modifier.fillMaxHeight().clickable(onClick = onClick), shape = RoundedCornerShape(22.dp), elevation = CardDefaults.cardElevation(4.dp)) {
        Box(Modifier.fillMaxSize().background(Green)) {
            if (bitmap != null) Image(bitmap!!, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxWidth().height(66.dp).align(Alignment.BottomCenter).background(Color(0x990D211C)))
            Text(title, Modifier.align(Alignment.BottomCenter).padding(horizontal = 6.dp, vertical = 18.dp), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}

@Composable private fun ReaderScreen(
    pager: androidx.compose.foundation.pager.PagerState,
    bookmark: Int,
    dark: Boolean,
    navigationMode: String,
    stableStatusBarHeight: androidx.compose.ui.unit.Dp,
    stableNavigationBarHeight: androidx.compose.ui.unit.Dp,
    onBack: () -> Unit,
    onBookmark: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var chromeVisible by rememberSaveable { mutableStateOf(true) }
    val activity = context as? ComponentActivity
    DisposableEffect(chromeVisible, activity) {
        val window = activity?.window
        val controller = window?.let { WindowInsetsControllerCompat(it, it.decorView) }
        if (chromeVisible) {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        } else {
            controller?.hide(WindowInsetsCompat.Type.systemBars())
            controller?.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
        }
    }
    val ink = if (dark) Color.White else Green
    Column(
        Modifier.fillMaxSize()
            .background(if (dark) Color(0xFF101B18) else Paper)
            // حجز الارتفاع الحقيقي المستقر لشريطي النظام حتى عند إخفائهما.
            .padding(top = stableStatusBarHeight, bottom = stableNavigationBarHeight)
    ) {
        if (chromeVisible) {
            Row(Modifier.fillMaxWidth().background(Green).heightIn(min = 58.dp).padding(horizontal = 6.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text("القرآن الكريم", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("الصفحة ${pager.currentPage + 1} من 3", color = Color(0xFFE8DCC3), fontSize = 11.sp)
                }
                IconButton(onClick = onBookmark) { Icon(Icons.Default.Bookmark, null, tint = if (bookmark == pager.currentPage + 1) Gold else Color.White) }
            }
        }
        HorizontalPager(
            state = pager,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            userScrollEnabled = navigationMode != "buttons",
            beyondViewportPageCount = 1
        ) { index ->
            val bitmap by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, index) {
                value = withContext(Dispatchers.IO) {
                    runCatching {
                        context.assets.open("mushaf-pages/${(index + 1).toString().padStart(3, '0')}.jpg").use {
                            BitmapFactory.decodeStream(it)?.asImageBitmap()
                        }
                    }.getOrNull()
                }
            }
            if (bitmap != null) {
                Box(
                    Modifier.fillMaxSize()
                        .padding(horizontal = 4.dp, vertical = 3.dp)
                        .pointerInput(index) { detectTapGestures(onTap = { chromeVisible = !chromeVisible }) },
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        bitmap!!,
                        contentDescription = "صفحة المصحف ${index + 1}",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("تعذر تحميل الصفحة", color = ink) }
            }
        }
        if (chromeVisible) {
            Row(Modifier.fillMaxWidth().background(if (dark) Color(0xFF1D2A26) else Color(0xFFECE5D5)).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (navigationMode != "swipe") TextButton(onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage - 1).coerceAtLeast(0)) } }, enabled = pager.currentPage > 0) { Text("السابقة") }
                Spacer(Modifier.weight(1f))
                Text("${pager.currentPage + 1} / 3", textAlign = TextAlign.Center, color = ink, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                if (navigationMode != "swipe") TextButton(onClick = { scope.launch { pager.animateScrollToPage((pager.currentPage + 1).coerceAtMost(2)) } }, enabled = pager.currentPage < 2) { Text("التالية") }
            }
        }
    }
}
