#!/usr/bin/env python3
"""Render first three official Hafs Mushaf pages for the demo build."""
import re, subprocess, sys, tempfile
from pathlib import Path
if len(sys.argv) != 3: raise SystemExit("Usage: render_mushaf.py <source-dir> <output-dir>")
src, out = Path(sys.argv[1]), Path(sys.argv[2])
pages=[]
for p in src.rglob('*.ai'):
    m=re.match(r'^(\d{3})___Hafs39__DM\.ai$',p.name,re.I)
    if m and 1 <= int(m.group(1)) <= 3: pages.append((int(m.group(1)),p))
pages.sort()
if [n for n,_ in pages] != [1,2,3]: raise SystemExit(f"Expected pages 001-003; found {[n for n,_ in pages]}")
out.mkdir(parents=True,exist_ok=True)
with tempfile.TemporaryDirectory(prefix='noor-demo-') as td:
    for n,p in pages:
        png=Path(td)/f'{n:03d}.png'; jpg=out/f'{n:03d}.jpg'
        subprocess.run(['inkscape',str(p),'--export-area-page','--export-width=1800','--export-background=#f7f5ef','--export-background-opacity=1',f'--export-filename={png}'],check=True,stdout=subprocess.DEVNULL)
        subprocess.run(['convert',str(png),'-background','#f7f5ef','-alpha','remove','-alpha','off','-fuzz','2%','-trim','+repage','-bordercolor','#f7f5ef','-border','24','-strip','-quality','93',str(jpg)],check=True,stdout=subprocess.DEVNULL)
if len(list(out.glob('*.jpg'))) != 3: raise SystemExit('Rendering failed: expected 3 JPG pages')
print('Verified: 3 demo pages rendered.')
